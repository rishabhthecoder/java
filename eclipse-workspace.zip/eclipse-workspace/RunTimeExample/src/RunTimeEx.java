

public class RunTimeEx {
public static void main(String arg[]) throws Exception {
	Runtime rt=Runtime.getRuntime();
	rt.exec("notepad");
	System.out.println("free memory :- "+rt.freeMemory());
	System.out.println("Total memory:- "+rt.totalMemory());
	System.gc();
	System.out.println("free memory after gc :- "+rt.freeMemory());
	System.out.println("Total memory after gc :- "+rt.totalMemory());
	System.out.println("Total number of processors available :-"+rt.availableProcessors());
}
}
