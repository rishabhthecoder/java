
public class StringMethods {
public static void main(String arg[]) {
	String a="Java ";
	String b="is a platform ";
	String c="independent language";
	System.out.println("length of string :-"+a.length());
	System.out.println("is Empty :-"+b.isEmpty());
	System.out.println("Searching methods>>>>");
	System.out.println("is \"form\" present in string "+b+" :- "+ b.contains("form")); 
	System.out.println("What is the index of \"l\" in "+c+" :- "+c.indexOf('l'));
	System.out.println("Compare \"java\" with "+a+" :-" +a.compareTo("java"));
	System.out.println("concat :-" +a.concat(b).concat(c));
	System.out.println("Substring :- "+b.substring(3,10));
}
}
