package com.cognizant.shapes;

public class Rectangle {
	private double length;
	private double breadth;

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getBreadth() {
		return breadth;
	}

	public void setBreadth(double breadth) {
		this.breadth = breadth;
	}

	public double calculateArea() {
		System.out.println("The Area of the rectangle is calculated using the formula length * breadth");
		// return 0.0;
		return length * breadth;
	}
}
