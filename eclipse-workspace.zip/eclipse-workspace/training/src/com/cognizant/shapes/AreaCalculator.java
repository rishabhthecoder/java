package com.cognizant.shapes;

import java.util.Scanner;

public class AreaCalculator extends Rectangle{
	public static void main(String arg[]) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		double length = sc.nextDouble();
		double breadth = sc.nextDouble();
		Rectangle r = new Rectangle();
		r.setLength(length);
		r.setBreadth(breadth);
		double area = r.calculateArea();
		System.out.println(area);
	}

}
