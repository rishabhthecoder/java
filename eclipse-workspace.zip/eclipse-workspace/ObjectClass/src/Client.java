
public class Client extends emp{
	public Client(String id, String name, String salary) {
		super(id, name, salary);
		// TODO Auto-generated constructor stub
	}

	public static void main(String arg[]) throws CloneNotSupportedException
	{
		emp e1=new emp("101","ram","2000");
		emp e2=new emp("102","ragh","3000");
		emp e3=(emp)e1.clone();
		emp e4=new emp("101","ram","2000");
		System.out.println(e1.getClass());
		System.out.println(e1.getClass().getSimpleName());
		System.out.println(e1.getClass().getTypeName());
		System.out.println(e1.equals(e2));
		System.out.println(e2.toString());
		System.out.println(e1.equals(e4));
		
	}

}
