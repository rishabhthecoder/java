
public class CheckObjectType {
	public static void main(String arg[])
	{
		CheckObjectType c1=new CheckObjectType();
		checkObjectType(1);
		checkObjectType(2l);
		checkObjectType("hello");
		checkObjectType(1.4f);
		checkObjectType(1.3d);
		checkObjectType(c1);
		
	}

	private static void checkObjectType(Object o) {
		// TODO Auto-generated method stub
		if(o instanceof Integer) {
			System.out.println(o+" is of type Integer.");
		}
		else if(o instanceof Float) {
			System.out.println(o+" is of type Float.");
		}
		else if(o instanceof String) {
			System.out.println(o+" is of type String.");
		}
		else
			System.out.println(o+" is of type "+o.getClass().getTypeName());
	}
	

}
