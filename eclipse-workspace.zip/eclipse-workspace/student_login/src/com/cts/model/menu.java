package com.cts.model;

import javax.servlet.http.HttpServlet;

@SuppressWarnings("serial")
public class menu extends HttpServlet
{
	public void me()
	{
		System.out.print("menu class is exceuted");
	}

}
