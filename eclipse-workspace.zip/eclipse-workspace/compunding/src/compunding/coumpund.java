package compunding;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/compunding")
@SuppressWarnings("serial")
public class coumpund extends HttpServlet
{
	
	protected void service(HttpServletRequest req,HttpServletResponse res) throws IOException,NullPointerException
	{
		PrintWriter ou=res.getWriter();
		try {
			System.out.println("servlet called");
			
			int p=Integer.parseInt(req.getParameter("p"));
			int r=Integer.parseInt(req.getParameter("r"));
			int n=Integer.parseInt(req.getParameter("n"));
			double t=1+(r*0.01);
			
			double k=p*t*((Math.pow(t, n)-1)/(t-1));
			ou.println(k);
			ou.print("total interest to be earned :-"+(k-(p*n)));		
		}
		catch (Exception E) {
			ou.println(E);
		}
		
	}

}
