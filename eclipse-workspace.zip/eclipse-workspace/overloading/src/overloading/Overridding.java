package overloading;

public class Overridding {
public static void main(String arg[]) {
	Dog d1=new Dog();
	Animal a1=new Animal();
	Animal a2= new Dog();
//	Dog d2= new Animal();
	d1.eat();
	a1.eat();
	a2.eat();
	
	//Overridding.eat();
}
}
