package overloading;

public class Overloading {
int add(int a,int b)
{
	return a+b;
}
int add(int a,int b,int c)
{
	return a+b+c;
}
public static void main(String arg[]) {
	Overloading o=new Overloading();
	System.out.println(o.add(2,3));
	System.out.println(o.add(2,3,5));
}
}
