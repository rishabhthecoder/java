package overloading;

public @interface overriden {

}
