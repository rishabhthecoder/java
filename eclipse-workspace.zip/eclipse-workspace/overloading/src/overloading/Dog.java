package overloading;

public class Dog extends Animal{


	public void eat()
	{
		System.out.println("eat() of derived class that is dog");
	}

}
