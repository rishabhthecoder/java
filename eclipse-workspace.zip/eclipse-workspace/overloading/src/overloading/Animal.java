package overloading;

public class Animal {

	public void eat()
	{
		System.out.println("eat() of base class");
	}
}
