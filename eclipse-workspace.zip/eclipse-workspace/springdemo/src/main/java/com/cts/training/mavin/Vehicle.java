package com.cts.training.mavin;

public interface Vehicle {

	void drive();
}
