package accessmodifier;
import second.C;
import first.*;
public class Main extends C {
	public static void main(String arg[]) {
		Main m=new Main();
		C c=new C();
		B b=new B();
		A a=new A();
		System.out.println("inside same package but different class");
		a.msg2();
		a.msg3();
		a.msg4();
		System.out.println(a.data2);
		System.out.println(a.data3);
		System.out.println(a.data4);
		
		System.out.println("\n\n\ninside different package and different class but not a sub class\n");
		b.msg2();
		System.out.println(b.data2);
		//m.msg4();
		//m.msg3();
		
		
		System.out.println("\n\n\ninside different package and different class but a sub class\n");
		c.msg2();
		System.out.println(c.data2);
		m.msg4();
		System.out.println(m.data4);
	}

}
