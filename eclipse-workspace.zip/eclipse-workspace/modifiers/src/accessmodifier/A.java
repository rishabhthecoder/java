package accessmodifier;

public class A {
	@SuppressWarnings("unused")
	private String data1="Hello this variable is from class A in package accessmodifier with private.";
	public String data2="Hello this variable is from class A in package accessmodifier with public.";
	String data3="Hello this variable is from class A in package accessmodifier with Default.";
	protected String data4="Hello this variable is from class A in package accessmodifier with protected.";
	@SuppressWarnings("unused")
	private void msg1() {
		System.out.println("Hello this method is from class A in package accessmodifier with private.");
	}
	public void msg2() {
		System.out.println("Hello this method is from class A in package accessmodifier with public.");
	}
	void msg3() {
		System.out.println("Hello this method is from class A in package accessmodifier with default.");
	}
	protected void msg4() {
		System.out.println("Hello this method is from class A in package accessmodifer with protected.");
	}

}
