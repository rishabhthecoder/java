package second;
 public class C  {
	
		@SuppressWarnings("unused")
		private String data1="Hello this variable is from class C in package second with private.";
		public String data2="Hello this variable is from class C in package second with public.";
		String data3="Hello this variable is from class C in package second with Default.";
		protected String data4="Hello this method is from class C in package second with protected.";
		@SuppressWarnings("unused")
		private void msg1() {
			System.out.println("Hello this method is from class C in package second with private.");
		}
		public void msg2() {
			System.out.println("Hello this method is from class C in package second with public.");
		}
		void msg3() {
			System.out.println("Hello this method is from class C in package second with default.");
		}
		protected void msg4() {
			System.out.println("Hello this method is from class C in package second with protected.");
		}

}
