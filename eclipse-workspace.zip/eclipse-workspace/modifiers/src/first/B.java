package first;

public class B {

	@SuppressWarnings("unused")
	private String data1="Hello this variable is from class b in package first with private.";
	public String data2="Hello this variable is from class b in package first with public.";
	String data3="Hello this variable is from class b in package first with default.";
	protected String data4="Hello this variable is from class b in package first with protected.";
	@SuppressWarnings("unused")
	private void msg1() {
		System.out.println("Hello this method is from class b in package first with private.");
	}
	public void msg2() {
		System.out.println("Hello this method is from class b in package first with public.");
	}
	void msg3() {
		System.out.println("Hello this method is from class b in package first with default.");
	}
	protected void msg4() {
		System.out.println("Hello this method is from class b in package first with protected.");
	}
}
