package nonaccessmodifer;

public abstract class Abstract {
	  public String fname = "John";
	  public int age = 24;
	  public abstract void study(); // abstract method
	}

