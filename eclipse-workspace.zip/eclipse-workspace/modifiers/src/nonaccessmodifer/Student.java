package nonaccessmodifer;

public class Student extends Abstract {
	public int graduationYear = 2018;

	public void study() {
		System.out.println("Studying all day long");
	}
}
