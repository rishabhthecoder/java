package com.main.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//secured page
@WebServlet("/home")
public class home extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		PrintWriter out = res.getWriter();
		HttpSession s = req.getSession();
		String u = (String) s.getAttribute("uName");
		if (u == null)
		{
			out.print("called welcome without user");
		//	res.sendRedirect("index.jsp");
		}else {
			out.print("welcome " + u);
			
		}
		s.removeAttribute("uName");
	}
}
