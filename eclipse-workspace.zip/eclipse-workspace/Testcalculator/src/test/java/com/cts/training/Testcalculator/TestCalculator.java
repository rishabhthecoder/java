package com.cts.training.Testcalculator;

import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class TestCalculator extends TestCase {
	
	Calculator c;
	CalculatorService cs;
	// testing done using junit
	@Before
	public void setUp()
	{
		this.c=new Calculator();
		this.cs=new CalculatorService();
	}
	
	@Test
	public void testAdd() {
		System.out.println("Test Begins");
		assertEquals(5,c.add(3, 2));
		
	}
	@Test
	public void testAdd2()
	{
		assertEquals(6,c.add(15, -9));
	}

}
