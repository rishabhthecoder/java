package com.cts.training.Testcalculator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

public class TestCalculatorService {
	
	CalculatorService cs;
	@Before
	public void setUp()
	{
		this.cs=new CalculatorService();

	}

	@Test
	public void test() {
		
	assertEquals(10,cs.perform(2, 3));
	//fail("Not yet implemented");
	}

}
