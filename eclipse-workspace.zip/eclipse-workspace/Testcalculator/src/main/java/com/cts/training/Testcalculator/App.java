package com.cts.training.Testcalculator;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		ApplicationContext c=new AnnotationConfigApplicationContext();
		Calculator c = ;
		System.out.println(c.add(2, 3));
	}
}
