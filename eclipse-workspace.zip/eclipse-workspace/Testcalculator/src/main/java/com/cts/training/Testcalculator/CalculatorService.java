package com.cts.training.Testcalculator;

public class CalculatorService extends Calculator {

	Calculator c;
	int perform(int i,int j)
	{
		return add(i,j)*i;
	}
}
