package com.cts.training.Testcalculator;

public class Calculator {
	public int add(int i,int j)
	{
		return i+j;
	}

}
